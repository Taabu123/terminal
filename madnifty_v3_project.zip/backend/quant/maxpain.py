
import random

def max_pain():
    return random.randint(23000,24000)
