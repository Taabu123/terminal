
import random

def delta_exposure():
    return round(random.uniform(-1,1),3)
