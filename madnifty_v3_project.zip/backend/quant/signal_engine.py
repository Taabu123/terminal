
def generate_signal(gamma, delta, pcr):

    score = (
        (gamma+1)/2 * 0.35 +
        (delta+1)/2 * 0.25 +
        (1.5 - abs(pcr-1)) * 0.40
    )

    if score > 0.65:
        decision = "BUY CALL"
    elif score < 0.35:
        decision = "BUY PUT"
    else:
        decision = "NO TRADE"

    return {
        "decision": decision,
        "confidence": round(score*100,2)
    }
