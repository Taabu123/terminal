
import random

def pcr_calc():
    return round(random.uniform(0.7,1.3),2)
