
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from quant.gamma import gamma_exposure
from quant.delta import delta_exposure
from quant.pcr import pcr_calc
from quant.maxpain import max_pain
from quant.signal_engine import generate_signal

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

@app.get("/api/signal")
def signal():
    gex = gamma_exposure()
    dex = delta_exposure()
    pcr = pcr_calc()
    mp = max_pain()

    signal = generate_signal(gex, dex, pcr)

    return {
        "gamma_exposure": gex,
        "delta_exposure": dex,
        "pcr": pcr,
        "max_pain": mp,
        "signal": signal["decision"],
        "confidence": signal["confidence"]
    }
