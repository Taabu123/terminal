
MadNifty v3 Institutional Terminal

Run Backend:

cd backend
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000

Open Dashboard:

frontend/index.html

Then connect Zerodha API in websocket_stream.py
and replace quant placeholder modules with real calculations.
